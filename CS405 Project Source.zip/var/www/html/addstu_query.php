<?php
$DOB = $_POST["dob"];
$First_Name = $_POST["first_name"];
$Last_Name = $_POST["last_name"];


$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM students WHERE sfname = '$First_Name' AND slname = '$Last_Name'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows === 1) {
		echo "Registration Failed! id already taken!\n";
		setcookie("bad". "bad", time()+10, "/");
		header("Location: ./addstu.php");
                die();
	}
	else {
		echo "Registration Sucessfull";
		$registration_query = "INSERT INTO students (sfname, slname, sdob) VALUE ('$First_Name', '$Last_Name', '$DOB')";
		if ( !$q_result = $mysqli->query($registration_query) ) {
                	echo "Add failed: ". $mysqli->error. "\n";
                	exit;
        	}
		setcookie("stuset". "stuset", time()+10, "/");
		header("Location: ./addstu.php");
		die();

	}
}
?> 
