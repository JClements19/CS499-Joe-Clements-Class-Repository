<?php
$T_ID = $_POST["t_id"];
$Room = $_POST["r_num"];


$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM teachers WHERE tid = '$T_ID'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows === 0) {
		echo "Registration Failed! id already taken!\n";
		setcookie("bad". "bad", time()+10, "/");
		header("Location: ./addteach.php");
                die();
	}
	else {
		echo "Registration Sucessfull";
		$registration_query = "UPDATE teachers SET Rnum = '$Room' WHERE tid = '$T_ID'";
		if ( !$q_result = $mysqli->query($registration_query) ) {
                	echo "Add failed: ". $mysqli->error. "\n";
                	exit;
        	}
		setcookie("teachchanged". "teachchanged", time()+10, "/");
		header("Location: ./addteach.php");
		die();

	}
}
?> 
