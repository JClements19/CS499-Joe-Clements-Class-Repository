<!DOCTYPE html>
<html lang="en">
<head>
  <title>DaycareCenterHome</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="slider.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      background-color: #99badd;
  }
  </style>
</head>

<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="homepage.php">One Unlucky Child Daycare Center</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="homepage.php">Home</a></li>
      <li><a href="teachers.php">Teachers</a></li>
      <li><a href="parents.php">Parents</a></li>
      <li><a href="administrators.php">Administrators</a></li>
      <li><a href="calendar.php">Calendar</a></li>
<?php
	if (isset($_COOKIE[user])) {
	echo '<li><a href="homepage.php"> Hello ' . $_COOKIE["user"] . '!</a></li><li> <a href="logout.php">Logout</a></li>';
	} else {
	echo ' <li><a href="loginpage_2.html">Sign In</a></li>
	<li><a href="registerpage.html">Sign Up</a></li>';
	}
?>
     </ul>
  </div>
</nav>
  <body style='background-color:carolina blue'>
    <div class="container" style="margin-top:50px">
      <h2>Welcome Parents, Teachers and Administrators!</h2>
    </div>
   </body>
     <div class ="slider">
	<slider>
		<slide><p></p></slide>
		<slide><p></p></slide>
		<slide><p></p></slide>
		<slide><p></p></slide>
		<slide><p></p></slide>
	</slider>
     </div>
</body>
</html>
