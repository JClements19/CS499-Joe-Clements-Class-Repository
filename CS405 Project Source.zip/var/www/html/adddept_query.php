<?php
$Dept_ID = $_POST["dept_id"];
$Dept_Name = $_POST["dept_name"];
$Dept_Head = $_POST["dept_head"];


$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM  departments WHERE depid = '$Dept_ID'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows === 1) {
		echo "Registration Failed! id already taken!\n";
		setcookie("bad". "bad", time()+10, "/");
		header("Location: ./adddept.php");
                die();
	}
	else {
		echo "Registration Sucessfull";
		$registration_query = "INSERT INTO departments (depid, dname, dephead) VALUE ('$Dept_ID', '$Dept_Name', '$Dept_Head')";
		if ( !$q_result = $mysqli->query($registration_query) ) {
                	echo "Add failed: ". $mysqli->error. "\n";
                	exit;
        	}
		setcookie("deptset". "deptset", time()+10, "/");
		header("Location: ./adddept.php");
		die();

	}
}
?> 
