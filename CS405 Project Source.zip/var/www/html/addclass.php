<html>
<body>
<Title>Students</Title>

<?php
if(isset($_COOKIE["stuset"])){
	echo "<p> Student added! </p>";
} else if(isset($_COOKIE["studel"])){
        echo "<p> Student Deleted! </p>";
}else if (isset($_COOKIE["bad"])) {
	echo "<p> Action failed </p>";
}
?>
<b>Add Student to Class</b>

<form action="addclass_query.php" method="post">
Student ID: <input type="text" name="s_id"><br>
Teacher ID: <input type="text" name="t_id"><br>
<input type="submit">
</form>
<b>Remove Student from Class</b>

<form action="delclass_query.php" method="post">
Student ID: <input type="text" name="s_id"><br>
Teacher ID: <input type="text" name="t_id"><br>
<input type="submit">
</form>

<b>Search Classes</b>

<form action="findclass_query.php" method="post">
Student ID: <input type="text" name="s_id"><br>
Teacher ID: <input type="text" name="t_id"><br>
<input type="submit">
</form>

</body>
</html>
