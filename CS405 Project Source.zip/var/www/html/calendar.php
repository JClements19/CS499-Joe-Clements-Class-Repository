<html>
<html lang="en">
<head>
  <title>Calendar of Events</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      background-color: #99badd;
  }
  </style>
</head>
<body style="height:1500px">

<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="homepage.php">One Unlucky Child Daycare Center</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="teachers.php">Teachers</a></li>
      <li><a href="parents.php">Parents</a></li>
      <li><a href="administrators.php">Administrators</a></li>
      <li class="active"><a href="calendar.php">Calendar</a></li>
      <?php
        if (isset($_COOKIE[user])) {
        echo '<li><a href="homepage.php"> Hello ' . $_COOKIE["user"] . '!</a></li><li> <a href="logout.php">Logout</a></li>';
        } else {
        echo ' <li><a href="loginpage_2.html">Sign In</a></li>
        <li><a href="registerpage.html">Sign Up</a></li>';
        }
?>
    </ul>
  </div>
</nav>
<body style='background-color:carolina blue'>
<div class="container" style="margin-top:50px">
  <h2>Calendar of Events</h2>
</div>

<div class="container-fluid">
<iframe src="https://calendar.google.com/calendar/embed?height=800&amp;wkst=1&amp;bgcolor=%23ffffff&amp;src=en.usa%23holiday%40group.v.calendar.google.com&amp;color=%232F6309&amp;src=kyfish.wildlife%40ky.gov&amp;color=%23853104&amp;ctz=America%2FNew_York" style="border:solid 1px #777" width="1200" height="800" frameborder="0" scrolling="no"></iframe>
</div>

</body>
</html>

