<?php
$First_Name = $_POST["first_name"];
$Last_Name = $_POST["last_name"];


$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

if ($First_Name == "") {
        $First_Name = "%";
}

if ($Last_Name == "") {
        $Last_Name = "%";
}
// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM  guardians NATURAL JOIN students NATURAL JOIN class NATURAL JOIN teachers WHERE gfname LIKE '$First_Name' AND glname LIKE '$Last_Name'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows != 0) {
		//echo "| Dept. ID | Dept. Name | Dept. Head |";
		echo "<table border='1'>";
		echo "<tr><td>Student First Name</td><td>Student Last Name</td><td>Student ID</td><td>Teacher First Name</td><td>Teacher Last Name</td><tr>";
		//echo "<br>";
		while ($row = mysqli_fetch_assoc($q_result)) {
			//echo "| ". $row["depid"]. " | ". $row["dname"]. " | ". $row["dephead"]. " |";
			echo "<tr><td>{$row['sfname']}</td><td>{$row['slname']}</td><td>{$row['sid']}</td><td>{$row['tfname']}</td><td>{$row['tlname']}</td><tr>";
			echo "<br>";
		}
		echo"</table>";
	}
	else {
		echo "No Results found for your search, please try again";
	}

	echo '<form action="addparent.php" method="post">
	<input type="submit" value="Back">
	</form>'; 
	}
?>
