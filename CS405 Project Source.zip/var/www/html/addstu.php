<html>
<body>
<Title>Students</Title>

<?php
if(isset($_COOKIE["stuset"])){
	echo "<p> Student added! </p>";
} else if(isset($_COOKIE["studel"])){
        echo "<p> Student Deleted! </p>";
}else if (isset($_COOKIE["bad"])) {
	echo "<p> Action failed </p>";
}
?>
<b>Add Students</b>

<form action="addstu_query.php" method="post">
First Name: <input type="text" name="first_name"><br>
Last Name: <input type="text" name="last_name"><br>
Date Of Birth: <input type="date" name="dob"><br>
<input type="submit">
</form>

<b>Delete Students</b>

<form action="delstu_query.php" method="post">
Student ID: <input type="text" name="s_id"><br>
<input type="submit">
</form>

<b>Search Students</b>

<form action="findstu_query.php" method="post">
Student ID: <input type="text" name="s_id"><br>
First Name: <input type="text" name="first_name"><br>
Last Name: <input type="text" name="last_name"><br>
<input type="submit">
</form>


</body>
</html>
