<?php
//This is a basic script showing how to connect to a local MySQL database
// and execute a query

// First, let's get our variables from the previous page
// remember, we stored them in a "post" variable called "professor"
$User_Name = $_POST["username"];
$Pass_Word = $_POST["password"];

// Now, we will create a mysqli object and connect to database
$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT Username FROM logins
				WHERE Username = '$User_Name'
				AND Password = '$Pass_Word'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows === 0) {
		echo "Login Failed! Please Register!\n";
		/*header("Location: ./loginpage_2.html");*/
		echo $User_Name;
	}
	else {
		echo "Login Sucessful" . "<br \>";
		setcookie("user", $User_Name, time() + 86400, "/");
		header("Location: ./homepage.php");
		exit();
	}
}

?> 
