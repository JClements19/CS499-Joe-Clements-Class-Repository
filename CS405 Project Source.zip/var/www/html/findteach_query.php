<?php
$T_ID = $_POST["t_id"];
$First_Name = $_POST["first_name"];
$Last_Name = $_POST["last_name"];
$R_Num = $_POST["r_num"];

$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

if ($T_ID == "") {
	$T_ID = "%";
}

if ($First_Name == "") {
        $First_Name = "%";
}

if ($Last_Name == "") {
        $Last_Name = "%";
}
if ($R_Num == "") {
        $R_Num = "%";
}

// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM  teachers WHERE tid LIKE '$T_ID' AND tfname LIKE '$First_Name' AND tlname LIKE '$Last_Name' AND rnum LIKE '$R_Num'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows != 0) {
		//echo "| Dept. ID | Dept. Name | Dept. Head |";
		echo "<table border='1'>";
		echo "<tr><td>Teacher Id</td><td>First Name</td><td>Last Name</td><td>Room Number</td><tr>";
		//echo "<br>";
		while ($row = mysqli_fetch_assoc($q_result)) {
			//echo "| ". $row["depid"]. " | ". $row["dname"]. " | ". $row["dephead"]. " |";
			echo "<tr><td>{$row['tid']}</td><td>{$row['tfname']}</td><td>{$row['tlname']}</td><td>{$row['rnum']}</td><tr>";
			echo "<br>";
		}
		echo"</table>";
	}
	else {
		echo "No Results found for your search, please try again";
	}

	echo '<form action="addteach.php" method="post">
	<input type="submit" value="Back">
	</form>'; 
	}
?>
