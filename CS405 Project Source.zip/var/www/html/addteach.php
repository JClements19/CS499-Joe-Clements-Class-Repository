<html>
<body>
<Title>Guardians</Title>

<?php
if(isset($_COOKIE["teachset"])){
	echo "<p> Teacher added! </p>";
} else if(isset($_COOKIIE["teachdel"])){
        echo "<p> Teacher Deleted! </p>";
} else if(isset($_COOKIIE["teachchanged"])){
        echo "<p> Room Changed! </p>";
}else if (isset($_COOKIE["bad"])) {
	echo "<p> Action failed </p>";
}
?>
<b>Add Teacher</b>

<form action="addteach_query.php" method="post">
First Name: <input type="text" name="first_name"><br>
Last Name: <input type="text" name="last_name"><br>
Room Number: <input type="text" name="r_num"><br>
<input type="submit">
</form>
<b>Delete Teacher</b>

<form action="delteach_query.php" method="post">
Teacher ID: <input type="number" name="t_id"><br>
<input type="submit">
</form>

<b>Change Room</b>

<form action="changeteach_query.php" method="post">
Teacher ID: <input type="number" name="t_id"><br>
New Room Number: <input type="text" name="r_num"><br>
<input type="submit">
</form>

<b>Search Teacher</b>

<form action="findteach_query.php" method="post">
Teacher ID: <input type="number" name="t_id"><br>
First Name: <input type="text" name="first_name"><br>
Last Name: <input type="text" name="last_name"><br>
Room Number: <input type="text" name="r_num"><br>
<input type="submit">
</form>

</body>
</html>
