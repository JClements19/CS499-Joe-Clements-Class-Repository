<html>
<html lang="en">
<head>
  <title>DaycareCenterHome</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      background-color: #99badd;
  }
  </style>
</head>
<body style="height:1500px">

<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="homepage.php">One Unlucky Child Daycare Center</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="teachers.php">Teachers</a></li>
      <li><a href="parents.php">Parents</a></li>
      <li class="active"><a href="administrators.php">Administrators</a></li>
      <li><a href="calendar.php">Calendar</a></li>
      <?php
        if (isset($_COOKIE[user])) {
        echo '<li><a href="homepage.php"> Hello ' . $_COOKIE["user"] . '!</a></li><li> <a href="logout.php">Logout</a></li>';
        } else {
        echo ' <li><a href="loginpage_2.html">Sign In</a></li>
        <li><a href="registerpage.html">Sign Up</a></li>';
        }
?>
    </ul>
  </div>
</nav>
<body style='background-color:carolina blue'>
<div class="container" style="margin-top:50px">
<br>
<iframe src="./adddept.php" height = "460" width = "360"></iframe>
<iframe src="./addteach.php" height = "460" width = "340"></iframe>
<br>
<iframe src="./addstu.php" height = "340" width = "360"></iframe>
<iframe src="./addguard.php" height = "340" width = "340"></iframe>
</div>

</body>
</html>
