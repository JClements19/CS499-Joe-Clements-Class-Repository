<?php
$Dept_ID = $_POST["dept_id"];
$Dept_Name = $_POST["dept_name"];
$Dept_Head = $_POST["dept_head"];


$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

if ($Dept_ID == "") {
	$Dept_ID = "%";
}

if ($Dept_Name == "") {
        $Dept_Name = "%";
}

if ($Dept_Head == "") {
        $Dept_Head = "%";
}
// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM  departments WHERE depid LIKE '$Dept_ID' AND dname LIKE '$Dept_Name' AND dephead LIKE '$Dept_Head'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows != 0) {
		//echo "| Dept. ID | Dept. Name | Dept. Head |";
		echo "<table border='1'>";
		echo "<tr><td>Dept. Id</td><td>Dept. Name</td><td>Dept. Head</td><tr>";
		//echo "<br>";
		while ($row = mysqli_fetch_assoc($q_result)) {
			//echo "| ". $row["depid"]. " | ". $row["dname"]. " | ". $row["dephead"]. " |";
			echo "<tr><td>{$row['depid']}</td><td>{$row['dname']}</td><td>{$row['dephead']}</td><tr>";
			echo "<br>";
		}
		echo"</table>";
	}
	else {
		echo "No Results found for your search, please try again";
	}

	echo '<form action="adddept.php" method="post">
	<input type="submit" value="Back">
	</form>'; 
	}
?>
