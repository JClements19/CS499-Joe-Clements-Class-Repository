<html>
<html lang="en">
<head>
  <title>UserLogin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="loginpage.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      background-color: #99badd;
  }
  </style>
</head>
<body style="height:1500px">

<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="homepage.php">One Unlucky Child Daycare Center</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="homepage.php">Home</a></li>
      <li><a href="teachers.php">Teachers</a></li>
      <li><a href="parents.php">Parents</a></li>
      <li><a href="administrators.php">Administrators</a></li>
      <li><a href="calendar.php">Calendar</a></li>
      <li><a href="loginpage.php">Sign In</a></li>
      <li><a href="register.php">Sign Up</a></li>
    </ul>
  </div>
</nav>
<body style='background-color:carolina blue'>
<div class="container" style="margin-top:50px">
  <h2>Welcome <span> back, <span> please <span> login <span> below</h2>
</div>


<!--
<form action="login_query.php" method="post">
Username: <input type="text" name="username">
Password: <input type="text" name="password">
<input type="submit">
</form>
--!>


<!--
<form action="register.php" method="post">
<input type="submit" value="REGISTER HERE!">
</form>
--!>

<form action="loginpage.php">
  <div class="imgcontainer">
    <img src="http://www.healthygallatin.org/wp-content/uploads/2013/04/School-Daycare-300x217.jpg" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>

    <br>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
    
    <br>
    
    <form action="login_query.php" method="post">
    <button type="submit">Login</button>
    </form>
    
    <form action="register.php" method="post">
    <button type="submit">Register</button>
    </form>

    <br>
     
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>

   </div>

  <div class="container" style="background-color:#fff">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>
</form>

</body>
</html>
