<html>
<body>
<Title>Departments</Title>

<?php
if(isset($_COOKIE["deptset"])){
	echo "<p> Department added! </p>";
} else if(isset($_COOKIE["deptdel"])){
        echo "<p> Department Deleted! </p>";
}else if(isset($_COOKIE["headset"])){
        echo "<p> Department Head Changed! </p>";
}else if (isset($_COOKIE["bad"])) {
	echo "<p> Action failed </p>";
}
?>
<b>Add Department</b>

<form action="adddept_query.php" method="post">
Department ID: <input type="text" name="dept_id"><br>
Department Name: <input type="text" name="dept_name"><br>
Department Head: <input type="text" name="dept_head"><br>
<input type="submit">
</form>
<b>Delete Department</b>

<form action="deldept_query.php" method="post">
Department ID: <input type="text" name="dept_id"><br>
<input type="submit">
</form>

<b>Change Department Head</b>

<form action="changedept_query.php" method="post">
Department ID: <input type="text" name="dept_id"><br>
New Department Head: <input type="text" name="dept_head"><br>
<input type="submit">
</form>

<b>Search Department</b>

<form action="finddept_query.php" method="post">
Department ID: <input type="text" name="dept_id"><br>
Department Name: <input type="text" name="dept_name"><br>
Department Head: <input type="text" name="dept_head"><br>
<input type="submit">
</form>

</body>
</html>
