<?php
// This is a basic script showing how to connect to a local MySQL database
// and execute a query

$User_Name = $_POST["username"];
$Pass_Word = $_POST["password"];

// Now, we will create a mysqli object and connect to database
$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM logins
				WHERE Username = '$User_Name'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if($User_Name == "" || $Pass_Word == ""){
		header("Location: ./registerpage.html");
		echo "Please fill out all necessary fields. \n";
		exit;
	}
	else if ($q_result->num_rows === 1) {
		header("Location: ./registerpage.html");
		echo "Registration Failed! Username already taken! \n";
		exit;
	}
	else {
		echo "Registration Sucessful" . "<br \>";
		$registration_query = "INSERT INTO logins (Username, Password)
					VALUE ('$User_Name', '$Pass_Word')";
		//$mysqli->query($registration_query);
		if ( !$q_result = $mysqli->query($registration_query) ) {
                echo "Registration failed: ". $mysqli->error. "\n";
                exit;
        }
		header("Location: ./loginpage_2.html");
	}
}
?> 
