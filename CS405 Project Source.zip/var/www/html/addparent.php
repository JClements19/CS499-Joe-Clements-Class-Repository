<html>
<body>
<Title>Students</Title>

<?php
if(isset($_COOKIE["stuset"])){
	echo "<p> Student added! </p>";
} else if(isset($_COOKIE["studel"])){
        echo "<p> Student Deleted! </p>";
}else if (isset($_COOKIE["bad"])) {
	echo "<p> Action failed </p>";
}
?>
<b>Enter Your Name:</b>

<form action="findparent_query.php" method="post">
First Name: <input type="text" name="first_nameo"><br>
Last Name: <input type="text" name="last_name"><br>
<input type="submit">
</form>

</body>
</html>
