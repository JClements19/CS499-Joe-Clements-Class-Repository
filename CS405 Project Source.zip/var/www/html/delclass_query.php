<?php
$T_ID = $_POST["t_id"];
$S_ID = $_POST["s_id"];

$Pass = 'Lacr0sse89'; //enter password
$DB = 'DaycareCenter'; //Enter database name
$mysqli = new mysqli('127.0.0.1', 'root',$Pass,$DB);

// Check for connection error
// If there is an error we will use $mysqli->connect_error
// to print the cause of the error
if ($mysqli->connect_errno) {
	echo "Could not connect to database \n";
	echo "Error: ". $mysqli->connect_error . "\n";
	exit;
} 
else {
	// Let's write the query and store it in a variable
	$login_query = "SELECT * FROM class WHERE tid LIKE '$T_ID' AND sid LIKE '$S_ID'";

	// Execute the query and check for error
	if ( !$q_result = $mysqli->query($login_query) ) {
		echo "Query failed: ". $mysqli->error. "\n";
		exit;
	}
	else if ($q_result->num_rows === 0) {
		echo "Failed! no Guardian!\n";
		setcookie("bad". "bad", time()+10, "/");
		header("Location: ./addteach.php");
                die();
	}
	else {
		echo "Deletion Sucessfull";
		$registration_query = "DELETE FROM class WHERE tid LIKE '$T_ID' AND sid LIKE '$S_ID'";
		if ( !$q_result = $mysqli->query($registration_query) ) {
                	echo "Add failed: ". $mysqli->error. "\n";
                	exit;
        	}
		setcookie("teachdel". "teachdel", time()+10, "/");
		header("Location: ./addclass.php");
		die();

	}
}
?> 
