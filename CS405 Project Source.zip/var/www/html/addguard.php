<html>
<body>
<Title>Guardians</Title>

<?php
if(isset($_COOKIE["guardset"])){
	echo "<p> Guardian added! </p>";
} else if(isset($_COOKIE["guarddel"])){
        echo "<p> Guardian Deleted! </p>";
}else if (isset($_COOKIE["bad"])) {
	echo "<p> Action failed </p>";
}
?>
<b>Add Guardian</b>

<form action="addguard_query.php" method="post">
Student ID: <input type="number" name="s_id">
<br>
First Name: <input type="text" name="first_name">
<br>
Last Name: <input type="text" name="last_name">
<br>
<input type="submit">
</form>
<b>Delete Guardian</b>

<form action="delguard_query.php" method="post">
Guardian ID: <input type="number" name="g_id">
<input type="submit">
</form>

<b>Search Guardian</b>

<form action="findgaurd_query.php" method="post">
Student ID: <input type="number" name="s_id">
<br>
First Name: <input type="text" name="first_name">
<br>
Last Name: <input type="text" name="last_name">
<br>
<input type="submit">
</form>
</body>
</html>
