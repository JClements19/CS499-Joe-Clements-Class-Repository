<html>
<body>

<html>
<html lang="en">
<head>
  <title>NewUserRegister</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      background-color: #99badd;
  }
  </style>
</head>
<body style="height:1500px">

<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="homepage.php">One Unlucky Child Daycare Center</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="teachers.php">Teachers</a></li>
      <li><a href="parents.php">Parents</a></li>
      <li><a href="administrators.php">Administrators</a></li>
      <li><a href="calendar.php">Calendar</a></li>
      <li><a href="loginpage_2.html">Sign In</a></li>
      <li class="active"><a href="register.php">Sign Up</a></li>
    </ul>
  </div>
</nav>
<body style='background-color:carolina blue'>
<div class="container" style="margin-top:50px">
  <h2>Please <span> register <span> below</h2>
</div>

<b>Registration</b>

<form action="register_query.php" method="post">
Username: <input type="text" name="username">
Password: <input type="text" name="password">
<input type="submit">
</form>

<form action="login.php" method="post">
<input type="submit" value="LOGIN HERE!">
</form>

</body>
</html>
